package za.ac.tut.entity;

public class Message {
    private String originator;
    private String message;

    public Message() {
    }

    public Message(String originator, String message) {
        this.originator = originator;
        this.message = message;
    }

    public String getOriginator() {
        return originator;
    }

    public void setOriginator(String originator) {
        this.originator = originator;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return originator + ", " + message ;
    }
    
}
