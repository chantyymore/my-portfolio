package za.ac.tut.bl;

import za.ac.tut.entity.Message;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.Instant;

public class MessageManagerHandler implements MessageManagerInterface<Message>{
    private Connection connection;

    public MessageManagerHandler() throws SQLException {
        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/MessagesDB","app","123");
    }
    
    @Override
    public boolean storeMEssage(Message m) throws SQLException {
       String sql ="INSERT INTO MESSAGE_TBL (ORIGINATOR,MESSAGE,RECORD_TIME)"
               + "VALUES(?,?,?)";
       PreparedStatement ps = connection.prepareStatement(sql);
       ps.setString(1,m.getOriginator());
       ps.setString(2, m.getMessage());
       ps.setTimestamp(3, Timestamp.from(Instant.now()));
       
       ps.executeUpdate();
       
       ps.close();
       return true;
    }
    
}
