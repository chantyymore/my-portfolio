package za.ac.tut.bl;

import java.sql.SQLException;

public interface MessageManagerInterface<Message> {
    public boolean storeMEssage(Message m)throws SQLException ;
}