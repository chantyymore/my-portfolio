
package messageserverapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.tut.bl.MessageThread;

public class MessageServerApp {

    public static void main(String[] args) {
        ServerSocket s;
        Socket socket;
        try {
            s = new ServerSocket(8383);
            while(true){
                socket = s.accept();
                MessageThread mt = new MessageThread(socket);
            }
        } catch (IOException ex) {
            Logger.getLogger(MessageServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
