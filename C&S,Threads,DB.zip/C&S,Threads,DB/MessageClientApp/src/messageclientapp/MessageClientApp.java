
package messageclientapp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MessageClientApp {

    public static void main(String[] args) {
        InetAddress addr;
        Socket socket;
        BufferedReader in;
        PrintWriter out;
        Scanner pad = new Scanner(System.in);
        
        try {
            addr = InetAddress.getByName("127.0.0.1");
            socket = new Socket(addr, 8383);
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            int option = showOption();
            while(true){
                if(option==1){
                    System.out.print("Enter your name: ");
                    String name = pad.nextLine();
                    System.out.print("Enter your message: ");
                    String message = pad.nextLine();
                    
                    out.println(name+"#"+message);
                }else if(option==2){
                    System.exit(0);
                }else{
                    System.out.println(option+" is invalid, Choose 1 or 2");
                }
                option = showOption();
            }
        } catch (UnknownHostException ex) {
            Logger.getLogger(MessageClientApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MessageClientApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    private static int showOption() {
        Scanner pad = new Scanner(System.in);
        System.out.print("Select one of the following options:\n"
                + "1-Send a message to the server\n"
                + "2-Exit the app\n\n"
                + "Your option: ");
        int option = pad.nextInt();
        return option;
    }
    
}
