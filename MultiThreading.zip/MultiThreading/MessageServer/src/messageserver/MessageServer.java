
package messageserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import za.ac.tut.bl.MessageThread;

public class MessageServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        ServerSocket s;
        Socket socket;
        PrintWriter out;
        BufferedReader in;
       
        
        s = new ServerSocket(9292);
        socket = s.accept();
        
        MessageThread mt =new MessageThread(socket);
    }
    
}
