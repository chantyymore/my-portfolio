/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model;

import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Student
 */
public class CoinTossingManager implements CoinTossingInterface{

    @Override
    public boolean checkCredentials(String username, String password, HttpServletRequest request) {
        String valUsername = request.getServletContext().getInitParameter("valid_username");
        String valPassword = request.getServletContext().getInitParameter("valid_password");
        boolean isValid = false;
        
        if(username.equals(valUsername) && password.equals(valPassword)){
            isValid = true;
        }
        return isValid;
        
    }
    
}
