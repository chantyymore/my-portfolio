package superfastdeliveries2;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import za.ac.tut.delivery.Delivery;

/**
 *
 * @author Mellow
 */
public class SuperFastDeliveries2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String[] deliveryInfo = {"2019:1:12.34", "2020:1:34.44", "2020:1:35.19", "2020:2:9.47", 
                                "2019:2:7.37", "2020:1:62.44", "2020:2:145.12", "2019:2:25.93", 
                                "2019:1:56.83", "2020:1:81.29", "2019:2:42.33", "2019:2:22.98",
                                "2020:1:35.23", "2019:1:44.44", "2019:2:108.54", "2020:2:92.11", 
                                "2019:2:21.21", "2020:1:101.23", "2020:1:3.55", "2019:1:64.22", 
                                "2019:2:76.36", "2020:2:64.39", "2019:1:17.04", "2020:1:7.59"};
        
        ArrayList<Delivery> deliveries= new ArrayList<>();
        for(int i=0;i<deliveryInfo.length;i++)
        {
            String[] tokens=deliveryInfo[i].split(":");
            
            int year=Integer.parseInt(tokens[0]);
            int number=Integer.parseInt(tokens[1]);
            int code=Integer.parseInt(tokens[2]);
            double weight=Double.parseDouble(tokens[3]);
            
            Delivery deliver=new Delivery(year, number, code, weight);
            deliveries.add(deliver);
        }
        String light=lightest(deliveries);
        JOptionPane.showMessageDialog(null, light);
       
        double avg =averageFee(deliveries,2014);
    }

    private static String lightest(ArrayList<Delivery> deliveries) {
       int lowest=0;
       int index=0;
       String lightest;
       for(int i=0;i<deliveries.size();i++)
       {
           if(deliveries.get(i).getWeight()<lowest)
           {
               index=i;
           }
       }
       
        return "lightest: "+deliveries.get(index).getDeliveryNumber();
       
    }

    private static double averageFee(ArrayList<Delivery> deliveries, int year) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
