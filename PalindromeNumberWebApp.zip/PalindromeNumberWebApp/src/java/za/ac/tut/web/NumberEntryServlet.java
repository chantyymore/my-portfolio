/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.PalindromeCheckInterface;
import za.ac.tut.model.PalindromeCheckManager;

/**
 *
 * @author keach
 */
public class NumberEntryServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer number = Integer.parseInt(request.getParameter("number"));
        //bl
        PalindromeCheckInterface pci = new PalindromeCheckManager();
        
        if(pci.isNumberValid(number)){
            boolean isPalindrome = pci.isNumberPalindrome(number);
            updateSession(session,isPalindrome);
            
            request.setAttribute("isPalindrome", isPalindrome);
            request.setAttribute("number", number);
            
            RequestDispatcher disp = request.getRequestDispatcher("outcome.jsp");
            disp.forward(request, response);
        }
        
    }

    private void updateSession(HttpSession session, boolean isPalindrome) {
        Integer tot = (Integer)session.getAttribute("tot");
        tot++;
        session.setAttribute("tot", tot);
        
        if(isPalindrome){
            Integer cnt = (Integer)session.getAttribute("cnt");
            cnt++;
            session.setAttribute("cnt", cnt);
        }
    }

  

}
