/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model;

/**
 *
 * @author keach
 */
public class PalindromeCheckManager implements PalindromeCheckInterface{

    @Override
    public boolean isNumberValid(Integer number) throws NumbersException {
       int remainder= number / 100;
       boolean isValid = false;
       if(remainder >0 && remainder < 10){
           isValid = true;
       }else{
           throw new NumbersException(number+ " is not a 3-digit number so it is invalid.");
       }
       return isValid;
    }

    @Override
    public boolean isNumberPalindrome(Integer number) {
       boolean isPalindrome=false;
       
       if(isThisNumberPalindrome(number)){
           isPalindrome=true;
       }
       return isPalindrome;
    }

    @Override
    public boolean isThisNumberPalindrome(Integer number) {
        Integer orgNo = number;
        Integer revNo = 0;
        boolean isPal = false;
        
        while(number != 0){
            revNo = revNo * 10 + number % 10;
            number = number / 10;
        }
        if(orgNo==revNo){
            isPal=true;
        }
         return isPal;
    }
    
}
