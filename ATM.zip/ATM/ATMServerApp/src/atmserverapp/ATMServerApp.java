
package atmserverapp;

public class ATMServerApp {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
