
package ac.za.tut.bl;

import ac.za.tut.entity.Account;

public interface AccountManagerInterface {
    public double getBalance(int idNo);
    public String withdraw(Account account);
    public String deposit(Account account);
}
