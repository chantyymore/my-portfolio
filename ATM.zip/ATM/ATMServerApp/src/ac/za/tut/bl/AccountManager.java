
package ac.za.tut.bl;

import ac.za.tut.entity.Account;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class AccountManager implements AccountManagerInterface{
    private Account account;
    private Connection connection;

    public AccountManager() throws SQLException {
        connection = DriverManager.getConnection("jdbc:derby://localhost:1527/atmDB", "app", "123");
    }
    
    @Override
    public double getBalance(int idNo) {
        double balance=0.0;
        //String sql = "SELECT AMOUNT "
        
        return balance;
    }

    @Override
    public String withdraw(Account account) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String deposit(Account account) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
