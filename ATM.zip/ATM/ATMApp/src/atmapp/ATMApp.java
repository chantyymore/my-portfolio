
package atmapp;

import ac.za.tut.bl.ATMFrame;
import java.io.IOException;

public class ATMApp {

    public static void main(String[] args) throws IOException {
        new ATMFrame();
    }
    
}
