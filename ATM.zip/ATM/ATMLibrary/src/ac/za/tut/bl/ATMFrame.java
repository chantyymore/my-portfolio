
package ac.za.tut.bl;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;


public class ATMFrame extends JFrame{
    private JPanel headingPnl,accountNumberpnl,passwordPnl
            ,amountPnl,btnsPnl,mainPnl,detailsCombinedPnl,plainTxtAreaPnl;
    
    private JLabel headingLbl,accountNumberLbl
            ,passwordLbl,amountLbl;
    
    private JTextField accountNumberTxf,amountTxf;
    
    private JPasswordField passwordTxf;
    
    private JScrollPane scrollableTextArea;
    
    private JButton depositBtn,withdrawBtn
                   ,balanceBtn,clearBtn,exit,statement;
    private JTextArea plainTxtArea;
   
    private InetAddress addr;
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    public ATMFrame() throws UnknownHostException, IOException{
        
        setTitle("ATM OPERATION");
        setSize(400,450);
        setResizable(true);
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        //streams
        addr = InetAddress.getByName("127.0.0.1");
        socket = new Socket(addr, 9292);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
        
        //panels
        headingPnl=new JPanel(new FlowLayout(FlowLayout.CENTER));
        accountNumberpnl=new JPanel(new FlowLayout(FlowLayout.LEFT));
        passwordPnl=new JPanel(new FlowLayout(FlowLayout.LEFT));
        amountPnl=new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnsPnl=new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        detailsCombinedPnl=new JPanel(new GridLayout(3,1));
        detailsCombinedPnl.setBorder(new TitledBorder(new LineBorder(Color.BLUE,2),"Login details"));
        
        plainTxtAreaPnl=new JPanel(new GridLayout(1,1));
        plainTxtAreaPnl.setBorder(new TitledBorder(new LineBorder(Color.BLUE,2),"Transtion details"));
        
        mainPnl=new JPanel(new BorderLayout());
        
        //labels
        headingLbl=new JLabel("Login");
        headingLbl.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
        headingLbl.setFont(new Font(Font.SANS_SERIF,Font.BOLD+Font.ITALIC,30));
        headingLbl.setForeground(Color.RED);
        
        
        accountNumberLbl=new JLabel("Account NO: ");
        passwordLbl=new JLabel("Password:    ");
        amountLbl=new JLabel("Amount R:     ");
        
        //fileds
        accountNumberTxf=new JTextField(20);
        passwordTxf=new JPasswordField(20);
        amountTxf=new JTextField(20);
        
        //buttons
        depositBtn=new JButton("Deposit");
        depositBtn.addActionListener(new DepositBtnListener());
        
        withdrawBtn=new JButton("Withdraw");
        withdrawBtn.addActionListener(new WithdrawBtnListener());
        
        balanceBtn=new JButton("Balance");
        balanceBtn.addActionListener(new BalanceBtnListener());
        
        clearBtn=new JButton("Clear");
        clearBtn.addActionListener(new ClearBtnListener());
        
        statement=new JButton("Bank Statement");
        statement.addActionListener(new statementBtnListener());
        
        exit=new JButton("Exit");
        exit.addActionListener(new ExitBtn());
        
        //textArea 
        plainTxtArea=new JTextArea(10,10);
        plainTxtArea.setEditable(false);
        
        
        scrollableTextArea=new JScrollPane(plainTxtArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        //adding
        headingPnl.add(headingLbl);
        
        accountNumberpnl.add(accountNumberLbl);
        accountNumberpnl.add(accountNumberTxf);
        
        passwordPnl.add(passwordLbl);
        passwordPnl.add(passwordTxf);
        
        amountPnl.add(amountLbl);
        amountPnl.add(amountTxf);
        
        detailsCombinedPnl.add(accountNumberpnl);
       // detailsCombinedPnl.add(passwordPnl);
        detailsCombinedPnl.add(amountPnl);
        
        btnsPnl.add(depositBtn);
        btnsPnl.add(withdrawBtn);
        btnsPnl.add(balanceBtn);
        btnsPnl.add(clearBtn);
        btnsPnl.add(statement);
        btnsPnl.add(exit);
        
        plainTxtAreaPnl.add(scrollableTextArea);
        
        mainPnl.add(headingPnl,BorderLayout.NORTH);
        mainPnl.add(detailsCombinedPnl,BorderLayout.CENTER);
        mainPnl.add(plainTxtAreaPnl,BorderLayout.SOUTH);
        
        add(mainPnl,BorderLayout.NORTH);
        add(btnsPnl,BorderLayout.CENTER);
        
        pack();
        setVisible(true);
    }

    private class statementBtnListener implements ActionListener
    {
        
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            
            
        }
    }

    private  class ExitBtn implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent e) {
        
        }
    }
    
     private class DepositBtnListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            //send data to the server
        }
    
    }
     private class WithdrawBtnListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
           
    }
     }
     private class BalanceBtnListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) 
        {
           
        }
    
    }
    private class ClearBtnListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
         
         }
    
    }
    
    
    
}
