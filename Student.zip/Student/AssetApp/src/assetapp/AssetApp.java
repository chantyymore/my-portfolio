
package assetapp;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import za.ac.tut.bl.AssetsManager;
import za.ac.tut.entity.Asset;

public class AssetApp {

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Scanner pad = new Scanner(System.in);
        Asset asset;
        AssetsManager am = new AssetsManager();
        Map<Integer,Asset> assets = new HashMap<>();
        File file = new File("Assets.txt");
        
        int option= showOption();
        while(option!=4){
            switch(option){
                case 1:
                    //add asset to map
                    System.out.print("Enter the asset number: ");
                    int assetNumber =pad.nextInt();
                    asset = createAsset();
                    assets.put(assetNumber, asset);
                    System.out.println("Asset added!");
                    break;
                case 2:
                    //store the map in a text file
                    am.store(assets, file);
                    System.out.println("Asset stored!");
                    break;
                case 3:
                    //to read map entires from file and diplay them
                    assets = am.getAssets(file);
                    for(Map.Entry<Integer,Asset> data: assets.entrySet()){
                        int assetNo =  data.getKey();
                        Asset description =  data.getValue();
                        System.out.println(assetNo+"-->"+description);
                    }
                    break;
                default:
                    System.out.println(option+" is invalid. Select only 1,2,3 or 4");
            }
            option= showOption();
        }
    }

    private static int showOption() {
        Scanner pad = new Scanner(System.in);
        System.out.print("Select one of the following options\n"
                + "1-To add an asset to a Map.\n"
                + "2-To store the Map entries.\n"
                + "3-To read the Map entries from the text file and display them.\n"
                + "4-To end the program\n\n"
                + "Your option:");
        int option = pad.nextInt();
        return option;
    }
    
    private static Asset createAsset(){
        Scanner pad = new Scanner(System.in);
        System.out.print("Enter your serial number: ");
        String serialNo = pad.next();
        System.out.print("Enter your description:");
        String description = pad.next();
        Asset asset = new Asset(serialNo, description);
        return asset;
    }
    
}
