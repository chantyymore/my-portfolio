
package za.ac.tut.bl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import za.ac.tut.entity.Student;

public class StudentManagerThread extends Thread{
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    StudentManagerDB db;

    public StudentManagerThread(Socket socket) throws IOException {
        this.socket = socket;
        out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        start();
    }

    @Override
    public void run() {
        String data;
        try {
            data = in.readLine();
            Student student ;
            List<Student> studs = new ArrayList<>();
            String[] token = data.split("#");
            String button = token[0];
            String outcome="";
            while (data != null) {
                if (button.equalsIgnoreCase("AddButton")) {
                    int studNo = Integer.parseInt(token[1]);
                    String name = token[2];
                    String surname = token[3];
                    Character gender = token[4].charAt(0);
                    String course = token[5];
                    student = new Student(studNo, name, surname, gender, course);
                    db = new StudentManagerDB(student);
                    outcome = db.addStudent(student);
                }else if(button.equalsIgnoreCase("DeleteButton")){
                    int idNo = Integer.parseInt(token[1]);
                    student = new Student(); 
                    db = new StudentManagerDB(student);
                    outcome = db.removeStudent(idNo);
                }else if(button.equalsIgnoreCase("DisplayButton")){
                    
                    if(studs == null){
                        System.out.println("The list is empty");
                    }else{
                        student = new Student(); 
                        db = new StudentManagerDB(student);
                        outcome = db.displayAll();
                    }
                        
                }else if(button.equalsIgnoreCase("UpdateButton")){
                    int studNo = Integer.parseInt(token[1]);
                    String surname = token[2];
                    student = new Student(); 
                    student.setStudNo(studNo);
                    student.setSurname(surname);
                    db = new StudentManagerDB(student);
                    outcome = db.updateStudent(student);
                }
                out.println(outcome);
                data = in.readLine();
            }
        } catch (IOException ex) {
            Logger.getLogger(StudentManagerThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StudentManagerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
}
