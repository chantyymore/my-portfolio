
package za.ac.tut.entity;

public class Student {
    private int studNo;
    private String name;
    private String surname;
    private Character Gender;
    private String course;

    public Student() {
    }

    public Student(int studNo, String name, String surname, Character Gender, String course) {
        this.studNo = studNo;
        this.name = name;
        this.surname = surname;
        this.Gender = Gender;
        this.course = course;
    }

    public int getStudNo() {
        return studNo;
    }

    public void setStudNo(int studNo) {
        this.studNo = studNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Character getGender() {
        return Gender;
    }

    public void setGender(Character Gender) {
        this.Gender = Gender;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    @Override
    public String toString() {
        return "Strudent no: " + studNo + ", Name: " + name + ", Surname: " + surname + ", Gender: " + Gender + ", Course: " + course ;
    }
    
    
}
