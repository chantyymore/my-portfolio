
package za.ac.tut.bl;

import java.sql.SQLException;
import java.util.List;
import za.ac.tut.entity.Student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class StudentManagerDB implements StudentManagerInterface<Student>{
    private Connection conn;
    private Student student;
    public StudentManagerDB(Student student) throws SQLException {
        conn = DriverManager.getConnection("jdbc:derby://localhost:1527/ClassListDB", "app", "123");
    }
    
    @Override
    public synchronized String addStudent(Student s) throws SQLException {
        String sql ="INSERT INTO STUDENT_TBL (STUDENT_NO,NAME,SURNAME,COURSE,GENDER) "
                + "VALUES (?,?,?,?,?) ";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,s.getStudNo());
        ps.setString(2, s.getName());
        ps.setString(3, s.getSurname());
        ps.setString(4, s.getCourse());
        ps.setString(5, s.getGender().toString());
        
        ps.executeUpdate();
        ps.close();
        String outcome = "Student added";
        return outcome;
    }

    @Override
    public synchronized String updateStudent(Student s) throws SQLException {
        String sql ="UPDATE STUDENT_TBL "
                + "SET SURNAME =? "
                + "WHERE STUDENT_NO =? ";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, s.getSurname());
        ps.setInt(2,s.getStudNo());
        
        ps.executeUpdate();
        ps.close();
        String outcome = "Student Updated";
        return outcome;
    }

    @Override
    public synchronized String removeStudent(int studNo) throws SQLException {
        String sql ="DELETE FROM STUDENT_TBL "
                + "WHERE STUDENT_NO=? "; 
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1,studNo);
        ps.executeUpdate();
        ps.close();
        String outcome = "Student Deleted";
        return outcome;
    }

    @Override
    public synchronized String displayAll() throws SQLException {
        String sql ="SELECT * FROM STUDENT_TBL ";  
        String outcome="";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        List<Student> studs = new ArrayList<>();
        while(rs.next()){
            int studNo = rs.getInt("STUDENT_NO");
            String name = rs.getString("NAME");
            String surname = rs.getString("SURNAME");
            String course = rs.getString("COURSE");
            Character gender = rs.getString("GENDER").charAt(0);
            
            Student student = new Student(studNo, name, surname, gender, course);
            studs.add(student);
            outcome = outcome + studNo+", "+name+", "+surname+", "+course+", "+gender+"\n";
        }
        return outcome;
    }
    
}
