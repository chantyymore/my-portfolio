
package za.ac.tut.bl;

import java.util.List;
import java.sql.SQLException;

public interface StudentManagerInterface<Student> {
    public String addStudent(Student s) throws SQLException;
    public String updateStudent(Student s) throws SQLException;
    public String removeStudent(int studNo) throws SQLException;
    public String  displayAll() throws SQLException;
}