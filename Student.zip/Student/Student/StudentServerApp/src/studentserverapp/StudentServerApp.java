
package studentserverapp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.tut.bl.StudentManagerThread;

public class StudentServerApp {

    public static void main(String[] args) {
        ServerSocket s;
        Socket socket;
        
        try {
            s = new ServerSocket(9292);
            System.out.println("Waiting for connection...");
            socket = s.accept();
            
            new StudentManagerThread(socket);
            
        } catch (IOException ex) {
            Logger.getLogger(StudentServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
