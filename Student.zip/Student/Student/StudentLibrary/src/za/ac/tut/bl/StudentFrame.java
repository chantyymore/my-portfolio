
package za.ac.tut.bl;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import za.ac.tut.entity.Student;

public class StudentFrame extends JFrame{
    private JPanel mainPnl,headingPnl,namePnl,surnamePnl,coursePnl,studNoPnl,genderPnl,displayPnl,btnPnl,collecPnl;
    private JLabel headingLbl,nameLbl,surnameLbl,courseLbl,studLbl,genderLbl;
    private JTextField nameTxtFld,surnameTxtFld,studTxtFld;
    private JComboBox courseCBx;
    private JRadioButton femaleRadBtn,maleRadBtn;
    private ButtonGroup btnGrp;
    private JTextArea displayTxtArea;
    private JButton addBtn,updateBtn,displayBtn,removeBtn,clearBtn;
    private JScrollPane scrollable;
    private Connection connection;
    private InetAddress addr;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Student student;

    public StudentFrame() throws IOException {
        setTitle("Students");
        setSize(500, 900);
        setDefaultLookAndFeelDecorated(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //create connetion and streams
        addr =InetAddress.getByName("127.0.0.1");
        socket = new Socket(addr, 9292);
        System.out.println("Starting connection...");
        out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        //create panels
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        namePnl= new JPanel(new FlowLayout(FlowLayout.LEFT));
        surnamePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        coursePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        studNoPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        displayPnl =new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        collecPnl = new JPanel(new GridLayout(6,1,1,1));
       
        //create labels
        headingLbl = new JLabel("Student Classlist");
        headingLbl.setFont(new Font(Font.SANS_SERIF,Font.ITALIC + Font.BOLD,20));
        headingLbl.setForeground(Color.blue);
        headingLbl.setBorder(new SoftBevelBorder(SoftBevelBorder.RAISED));
        
        nameLbl = new JLabel("Name:"); 
        surnameLbl = new JLabel("Surname:"); 
        courseLbl =new JLabel("Course name:"); 
        studLbl = new JLabel("Student No:"); 
        genderLbl = new JLabel("Gender"); 
        //create textfield
        nameTxtFld = new JTextField(15);
        surnameTxtFld = new JTextField(15);
        studTxtFld = new JTextField(15);
        //create combo box
        courseCBx = new JComboBox();
        courseCBx.addItem("Computer Science");
        courseCBx.addItem("Information Technology");
        courseCBx.addItem("Informatics");
        courseCBx.addItem("Multimedia");
        courseCBx.addItem("Computer Systems Engineering");
        //create radio box
        femaleRadBtn = new JRadioButton("Female");
        maleRadBtn = new JRadioButton("Male");
        //create button group
        btnGrp = new ButtonGroup();
        //Add to button group
        btnGrp.add(femaleRadBtn);
        btnGrp.add(maleRadBtn);
        //create text area
        displayTxtArea = new JTextArea(15, 50);
        displayTxtArea.setBorder(new TitledBorder(new LineBorder(Color.blue,2),"Display"));
        //create scrollapane
        scrollable = new JScrollPane(displayTxtArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        //create buttons
        addBtn = new JButton("ADD");
        addBtn.addActionListener(new AddStudentHandler());
        updateBtn = new JButton("UPDATE");
        updateBtn.addActionListener(new UpdateStudentHandler());
        removeBtn = new JButton("REMOVE");
        removeBtn.addActionListener(new RemoveBtnHandler());
        displayBtn = new JButton("DISPLAY");
        displayBtn.addActionListener(new DisplayBtnHandler());
        clearBtn = new JButton("CLEAR");
        clearBtn.addActionListener(new ClearBtnHAndler());
        
        mainPnl = new JPanel(new BorderLayout());
        //adding objects to their panels
        headingPnl.add(headingLbl);
        namePnl.add(nameLbl);
        namePnl.add(nameTxtFld);
        surnamePnl.add(surnameLbl);
        surnamePnl.add(surnameTxtFld);
        coursePnl.add(courseLbl);
        coursePnl.add(courseCBx);
        studNoPnl.add(studLbl);
        studNoPnl.add(studTxtFld);
        genderPnl.add(genderLbl);
        genderPnl.add(femaleRadBtn);
        genderPnl.add(maleRadBtn);
        displayPnl.add(scrollable);
        btnPnl.add(addBtn);
        btnPnl.add(updateBtn);
        btnPnl.add(removeBtn);
        btnPnl.add(displayBtn);
        btnPnl.add(clearBtn);
        
        collecPnl.add(namePnl);
        collecPnl.add(surnamePnl);
        collecPnl.add(coursePnl);
        collecPnl.add(studNoPnl);
        collecPnl.add(genderPnl);
        collecPnl.add(btnPnl);
       
        
        mainPnl.add(headingPnl, BorderLayout.NORTH);
        mainPnl.add(collecPnl, BorderLayout.CENTER);
        mainPnl.add(displayPnl, BorderLayout.SOUTH);
        
        add(mainPnl);
        pack();
        setResizable(false);
        setVisible(true);
       
    }
    
    public void clear(){
        nameTxtFld.setText("");
        surnameTxtFld.setText("");
        femaleRadBtn.setSelected(false);
        maleRadBtn.setSelected(false);
        displayTxtArea.setText("");
        studTxtFld.setText("");
    }

    private  class ClearBtnHAndler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            clear();
        }
    }

    private class DisplayBtnHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
           out.println("DisplayButton");
           String data ;
            try {
                
                data = in.readLine();
                displayTxtArea.setText(data);
            } catch (IOException ex) {
                Logger.getLogger(StudentFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
           
        }
    }

    private class RemoveBtnHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            int idNo = Integer.parseInt(JOptionPane.showInputDialog(StudentFrame.this, "Enter the student no of a student you want to update: "));
            
            out.println("DeleteButton"+"#"+idNo);
            
            try {
                String data = in.readLine();
                displayTxtArea.setText(data);
            } catch (IOException ex) {
                Logger.getLogger(StudentFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class AddStudentHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String data;
            
                String name = nameTxtFld.getText();
                String surname = surnameTxtFld.getText();
                String course = (String)courseCBx.getSelectedItem();
                int studNo = Integer.parseInt(studTxtFld.getText());
                Character gender='M';
                if(femaleRadBtn.isSelected()){
                    gender ='F';
                }else if(maleRadBtn.isSelected()){
                    gender ='M';
                }
                //Student student = new Student(studNo, name, surname, gender, course);
                System.out.println("Adding student...");
                out.println("AddButton#"+studNo+"#"+name+"#"+surname+"#"+gender+"#"+course);
                try { 
                    data = in.readLine();
                    displayTxtArea.setText(data);
                } catch (IOException ex) {
                    Logger.getLogger(StudentFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
         
        }
    }
    
    private  class UpdateStudentHandler implements ActionListener {
        //not working
        @Override
        public void actionPerformed(ActionEvent e) {
            int idNo = Integer.parseInt(JOptionPane.showInputDialog(StudentFrame.this, "Enter the student no of a student you want to update: "));
            String surname = JOptionPane.showInputDialog(StudentFrame.this, "Enter the surname you want to change: ");
            out.println("UpdateButton#" + idNo + "#" + surname);
            String data;
            try {
                data = in.readLine();
                displayTxtArea.setText(data);
            } catch (IOException ex) {
                Logger.getLogger(StudentFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
}
