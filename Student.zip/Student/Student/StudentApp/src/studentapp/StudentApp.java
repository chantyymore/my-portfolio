
package studentapp;

import java.io.IOException;
import za.ac.tut.bl.StudentFrame;

public class StudentApp {

    public static void main(String[] args) throws IOException {
        new StudentFrame();
    }
    
}
