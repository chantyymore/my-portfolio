package sacountry;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import za.ac.tut.city.City;

public class SACountry {

    public static void main(String[] args) {
        String[] citiesInfo = {"Kimberley#Northern Cape#175860", "Chatsworth#KwaZulu-Natal#192166", 
					"Katlehong#Gauteng#349866", "Port Elizabeth#Eastern Cape#237500", 
					"Khayelitsha#Western Cape#329002", "Pretoria#Gauteng#525387", 
					"Bloemfontein#Free State#217076", "Tshivhase#Limpopo#226622", 
					"Soweto#Gauteng#858644", "Pietermaritzburg#KwaZulu-Natal#223519",
					"Burban#KwaZulu-Natal#536644", "Nelspruit#Mpumalanga#359600", 
					"Johannesburg#Gauteng#1009035", "Mamelodi#Gauteng#256117"};
        //declare and initialize a City list of objects
        ArrayList<City> cities =new ArrayList<>();
        //populate
        for(int i=0;i<citiesInfo.length;i++){
            //split
            String[] token = citiesInfo[i].split("#");
            
            String name = token[0];
            String province = token[1];
            int population = Integer.parseInt(token[2]);
            
            City city = new City(name);
            city.setProvince(province);
            city.setPopulation(population);
            
            cities.add(city);
        }
        String nameOfProvince = "Gauteng";
        JOptionPane.showMessageDialog(null, "The city with the highest population is "+highestPopulation(cities));
        int countCity = citiesPerProvince(cities,nameOfProvince);
        JOptionPane.showMessageDialog(null, "There are "+countCity+" citites in Gauteng");
        double perc=0.0;
        updatePopulation(cities,perc);
    }
    public static String highestPopulation(ArrayList<City> cities){
        int index=0;
        int highest = 0;
        for(int i=0;i<cities.size();i++){
            
            int population = cities.get(i).getPopulation();
            if(population > highest){
                index =i;
            }
        }
        return cities.get(index).getName();
    }
    public static int citiesPerProvince(ArrayList<City> cities,String name){
        int count=0;
        name = "Gauteng";
        for(int i=0;i<cities.size();i++){
            if(cities.get(i).getProvince().equalsIgnoreCase(name)){
              count++;
            }
        }
        return count;
    }
    public static void updatePopulation(ArrayList<City> cities, double perc){
        perc = (2.36/100)+1;
        int populationIncrease=0;
        for(int i=0;i<cities.size();i++){
            populationIncrease = (int) ((cities.get(i).getPopulation())*perc);
            System.out.println(populationIncrease);
        }
    }
}
