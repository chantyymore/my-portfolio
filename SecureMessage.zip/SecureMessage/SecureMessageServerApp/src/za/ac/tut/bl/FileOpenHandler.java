
package za.ac.tut.bl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;

public class FileOpenHandler implements FileOpenInterface{
    private BufferedReader br;
    private int val;
    private JFileChooser fc;
    private File file;
    private String data,record="";

    public FileOpenHandler() {
    }

    
    @Override
    public synchronized String openFile() {
        fc = new JFileChooser();
        val = fc.showOpenDialog(null);
        if(val==JFileChooser.APPROVE_OPTION){
            file = fc.getSelectedFile();
            
            try {
                br = new BufferedReader(new FileReader(file));
                while((data=br.readLine())!=null){
                    record += data+"\n";
                }
                br.close();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FileOpenHandler.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FileOpenHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return record;
    }

    
   
    
}
