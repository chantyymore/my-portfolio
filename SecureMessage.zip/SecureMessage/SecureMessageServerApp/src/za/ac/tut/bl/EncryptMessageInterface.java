
package za.ac.tut.bl;

public interface EncryptMessageInterface {
    public String encrypt(String message);
}
