
package za.ac.tut.bl;

public class EncryptMessageHandler implements EncryptMessageInterface{

    public EncryptMessageHandler() {
    }
    

    @Override
    public String encrypt(String message) {
        //a=1,e=2,i=3,o=4,u=5
        String encrypt ="";
        char replace;
        for(int i=0;i<message.length();i++){
            char messageChar = message.charAt(i);
            switch(messageChar){
                case 'a':
                    replace ='1';
                    break;
                case 'e':
                    replace ='2';
                    break;
                case 'i':
                    replace ='3';
                    break;
                case 'o':
                    replace ='4';
                    break;
                case 'u':
                    replace ='5';
                    break;
                default:
                    replace = messageChar;
            }
            encrypt = encrypt +Character.toString(replace);
        }
        return encrypt;
    }
    
}
