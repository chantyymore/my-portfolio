
package za.ac.tut.bl;

public class SaveMessageHandler {
    
}
