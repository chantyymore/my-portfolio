
package za.ac.tut.bl;

import java.io.File;

public interface FileOpenInterface {
    public String openFile();
}
