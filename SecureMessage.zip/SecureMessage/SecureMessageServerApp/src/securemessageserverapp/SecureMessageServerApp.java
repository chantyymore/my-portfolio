
package securemessageserverapp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import za.ac.tut.bl.SecureMessageThread;

public class SecureMessageServerApp {

    public static void main(String[] args) throws IOException {
        ServerSocket s;
        Socket socket;
        
        s = new ServerSocket(9292);
        socket = s.accept();
        System.out.println("Waiting for connection...");
        System.out.println("Connection established");
        SecureMessageThread st = new SecureMessageThread(socket);
                
    }
    
}
