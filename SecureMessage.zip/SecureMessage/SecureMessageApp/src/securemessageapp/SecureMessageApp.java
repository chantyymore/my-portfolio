
package securemessageapp;

import java.io.IOException;
import za.ac.tut.ui.SecureMessageFrame;

public class SecureMessageApp {

    public static void main(String[] args) throws IOException {
        new SecureMessageFrame();
    }
    
}
