/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ui;
  
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class SecureMessageFrame extends JFrame{
    //menu bar
    private JMenuBar menuBar;
    
    //menu 
    private JMenu fileMenu;
    
    //menu items
    private JMenuItem openFileMenuItem;
    private JMenuItem encryptFileMenuItem;
    private JMenuItem saveEncryptedFileMenuItem;
    private JMenuItem clearFileMenuItem;
    private JMenuItem exitFileMenuItem;
    
    //panels
    private JPanel headingPnl;
    private JPanel plainTextPnl;
    private JPanel encryptedTextPnl;
    private JPanel mainPnl;
    
    //label
    private JLabel headingLbl;
    
    //text area
    private JTextArea plainMsgTxtArea;
    private JTextArea encryptedMsgTxtArea;

    //text area
    private JScrollPane scrollablePlainMsgTxtArea;
    private JScrollPane scrollableEncryptedMsgTxtArea;
    
    private InetAddress addr;
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
        
    public SecureMessageFrame() throws UnknownHostException, IOException{
        //initialise the frame
        setTitle("Secure Messages");
        setSize(50, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        //creating stream
        addr = InetAddress.getByName("127.0.0.1");
        socket = new Socket(addr,9292);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
        System.out.println("Sending a connection");
        //create menu bar
        menuBar = new JMenuBar();
        
        //create menu 
        fileMenu = new JMenu("File");
        
        //create menu items
        openFileMenuItem = new JMenuItem("Open file...") ;
        openFileMenuItem.addActionListener(new OpenFileMenuItemListener());
        
        encryptFileMenuItem = new JMenuItem("Encrypt message...") ;
        encryptFileMenuItem.addActionListener(new EncryptFileMenuItemListener());
        
        saveEncryptedFileMenuItem = new JMenuItem("Save encrypted message...") ;
        saveEncryptedFileMenuItem.addActionListener(new SaveEncryptedFileMenuItemListener());
        
        clearFileMenuItem = new JMenuItem("Clear") ;
        clearFileMenuItem.addActionListener(new ClearFileMenuItemListener());

        exitFileMenuItem = new JMenuItem("Exit") ;
        exitFileMenuItem.addActionListener(new ExitFileMenuItemListener());
        
        //add menu items to menu
        fileMenu.add(openFileMenuItem);
        fileMenu.add(encryptFileMenuItem);
        fileMenu.add(saveEncryptedFileMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(clearFileMenuItem);
        fileMenu.add(exitFileMenuItem);
        
        //add menu to the menu bar
        menuBar.add(fileMenu);

        //create panels
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        plainTextPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        plainTextPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1), "Plain message"));
        
        encryptedTextPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        encryptedTextPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK, 1), "Encrypted message"));
        
        mainPnl = new JPanel(new BorderLayout());
        
        //create label
        headingLbl = new JLabel("Message Encryptor");
        headingLbl.setForeground(Color.BLUE);
        headingLbl.setFont(new Font("SERIF", Font.BOLD + Font.ITALIC, 30));
        headingLbl.setBorder(new BevelBorder(BevelBorder.RAISED));
        
        //text areas
        plainMsgTxtArea = new JTextArea(10,30);
        plainMsgTxtArea.setEditable(false);
        
        encryptedMsgTxtArea = new JTextArea(10, 30);
        encryptedMsgTxtArea.setEditable(false);
        
        //make the text areas scrollable
        scrollablePlainMsgTxtArea = new JScrollPane(plainMsgTxtArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollableEncryptedMsgTxtArea = new JScrollPane(encryptedMsgTxtArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        //add components to panels
        headingPnl.add(headingLbl);
        plainTextPnl.add(scrollablePlainMsgTxtArea);
        encryptedTextPnl.add(scrollableEncryptedMsgTxtArea);
        
        mainPnl.add(headingPnl, BorderLayout.NORTH);
        mainPnl.add(plainTextPnl, BorderLayout.WEST);
        mainPnl.add(encryptedTextPnl, BorderLayout.EAST);
                 
        //add the menu bar to the frame
        setJMenuBar(menuBar);
        
        //add main panel to the frame
        add(mainPnl);
        
        //pack the components
        pack();
        
        //set resizable
        setResizable(false);
        
        //visible
        setVisible(true);
    }
    
    //anonymous class for opening a plain text file. It handles the Open file menu item.
    private class OpenFileMenuItemListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {     
            try {
                //String message = plainMsgTxtArea.getText();
                String button = "OpenFileBtn";
                out.println(button);
                String data = in.readLine();
                plainMsgTxtArea.setText(data);
            } catch (IOException ex) {
                Logger.getLogger(SecureMessageFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
                
                
        }
    }

    //anonymous class for encrypting the message. It handles the Encrypt message menu item.
    private class EncryptFileMenuItemListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {      
            try {
                //write your code here
                String message = plainMsgTxtArea.getText();
                String button = "EncryptBtn";
                out.println(button+"#"+message);
                
                String data = in.readLine();
                plainMsgTxtArea.setText(data);
            } catch (IOException ex) {
                Logger.getLogger(SecureMessageFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
         }
    }

    //anonymous class for saving encrypted message. It handles the Save encrypted message menu item.
    private class SaveEncryptedFileMenuItemListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {    
		//write your code here  
         }
    }
  
    //anonymous class for clearing the respective text areas. It handles the clear menu item
    private class ClearFileMenuItemListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            //write your code here
        }
        
    }
    
    //anonymous class for exiting the application. It handles the exit menu item
    private class ExitFileMenuItemListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            //write your code here
        }
        
    }
}


