/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.StudentFacadeLocal;
import za.ac.tut.model.entities.Student;


public class UpdateServlet extends HttpServlet {
    @EJB StudentFacadeLocal sb;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long studNo = Long.parseLong(request.getParameter("studNo"));
        String[] modules =(String[])request.getParameterValues("modules[]");
        
        Student stud = createStudent(studNo,modules);
        sb.edit(stud);
        request.setAttribute("stud", stud);
        
        
        RequestDispatcher disp = request.getRequestDispatcher("update_outcome.jsp");
        disp.forward(request, response);
    }

    private Student createStudent(Long studNo,String[] modules) {
        Student s = new Student();
        sb.find(studNo);
        s.setModules(modules);
        return s;
    }

    
}
