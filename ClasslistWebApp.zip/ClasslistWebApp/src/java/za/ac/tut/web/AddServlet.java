/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.model.bl.StudentFacadeLocal;
import za.ac.tut.model.entities.Student;

/**
 *
 * @author keach
 */
@WebServlet("/upload")
@MultipartConfig
public class AddServlet extends HttpServlet {
    @EJB StudentFacadeLocal sb;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Long studNo = Long.parseLong(request.getParameter("studNo"));
        String name = request.getParameter("name");
        Integer age = Integer.parseInt(request.getParameter("age"));
        Character gender = request.getParameter("gender").charAt(0);
        String[] modules = (String[])request.getParameterValues("modules[]");
        Part imgPart = request.getPart("img");
        
        byte[] image = createPicture(imgPart);
        
        Student stud = createStudent(studNo,name,age,gender,modules,image);
        sb.create(stud);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_outcome.jsp");
        disp.forward(request, response);
    }

    private byte[] createPicture(Part imgPart) throws IOException {
        InputStream in = imgPart.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int size =0;
        
        while((size = in.read(buffer)) != -1){
            out.write(buffer, 0, size);
        }
        
        byte[] blob = out.toByteArray();
        return blob;
    }

    private Student createStudent(Long studNo, String name, Integer age, Character gender, String[] modules, byte[] image) {
        Student s = new Student();
        s.setStudNo(studNo);
        s.setName(name);
        s.setAge(age);
        s.setGender(gender);
        s.setModules(modules);
        s.setPicture(image);
        s.setRegDate(new Date());
        return s;
    }

}
