/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.LearnerFacadeLocal;
import za.ac.tut.model.entities.Learner;

/**
 *
 * @author keach
 */
@WebServlet(name = "GetLearnerPerGenderServlet", urlPatterns = {"/GetLearnerPerGenderServlet"})
public class GetLearnerPerGenderServlet extends HttpServlet {
    @EJB LearnerFacadeLocal sb;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            Character gender = request.getParameter("gender").charAt(0);
            
            List<Learner> list = (List<Learner>)sb.getLearnerPerGender(gender);
            request.setAttribute("list", list);
            
            RequestDispatcher disp = request.getRequestDispatcher("per_gender_outcome.jsp");
            disp.forward(request, response);
    }

   
}
