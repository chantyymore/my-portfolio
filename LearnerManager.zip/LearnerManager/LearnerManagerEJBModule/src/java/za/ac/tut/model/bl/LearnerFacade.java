/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.model.entities.Learner;

/**
 *
 * @author keach
 */
@Stateless
public class LearnerFacade extends AbstractFacade<Learner> implements LearnerFacadeLocal {

    @PersistenceContext(unitName = "LearnerManagerEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public LearnerFacade() {
        super(Learner.class);
    }

    @Override
    public Learner youngestFemale() {
        Query query = em.createQuery("SELECT l FROM Learner l WHERE l.age = (SELECT MIN(l2.age) FROM Learner l2 WHERE l2.gender = 'Female') AND l.gender = 'Female'");
        Learner learner = (Learner)query.getSingleResult();
        return learner;
        
    }

    @Override
    public List<Learner> getLearnerPerGender(Character gender) {
        Query query = em.createQuery("SELECT l FROM Learner l WHERE l.gender=?1");
        query.setParameter(1, gender);
        List<Learner> list = (List<Learner>)query.getResultList();
        return list;
    }

    @Override
    public Integer cntAllMales() {
        Query query = em.createQuery("SELECT COUNT(l) FROM Learner l WHERE l.gender='M'");
        Integer cnt = (Integer)query.getSingleResult();
        return cnt;
    }

    @Override
    public Integer avgClass() {
        Query query = em.createQuery("SELECT AVG(l) FROM Learner l");
        Integer cnt = (Integer)query.getSingleResult();
        return cnt;
    }

    @Override
    public List<Learner> findLearnerWithinAgeRange(Integer minAge, Integer maxAge) {
        Query query = em.createQuery("SELECT l FROM Learner l WHERE l.age<=?1 AND l.age >=?2");
        query.setParameter(1,minAge);
        query.setParameter(2, maxAge);
        List<Learner> list = (List<Learner>)query.getResultList();
        return list;
    }
    
}
