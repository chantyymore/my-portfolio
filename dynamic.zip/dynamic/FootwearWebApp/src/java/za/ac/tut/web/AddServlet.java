/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.ShoeFacadeLocal;
import za.ac.tut.entities.Shoe;

/**
 *
 * @author keach
 */
public class AddServlet extends HttpServlet {
    
    @EJB ShoeFacadeLocal sb;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String[] brands = (String[])request.getParameterValues("brands[]");
        
        Shoe s = createShoe(name,brands);
        sb.create(s);
        request.setAttribute("name", name);
        request.setAttribute("brands", brands);
        
        RequestDispatcher disp = request.getRequestDispatcher("add_outcome.jsp");
        disp.forward(request, response);
    }

    private Shoe createShoe(String name, String[] brands) {
        Shoe s = new Shoe();
        s.setName(name);
        s.setBrands(brands);
        return s;
    }


}
