
package za.ac.tut.bl;

import za.ac.tut.entity.Person;

public class PersonThread implements Runnable{
    private Person person;

    public PersonThread(Person person) {
        this.person = person;
    }
    
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+" started.");
        for(int i=0;i<5;i++){
            person.incrementAge();
            System.out.println(Thread.currentThread().getName()+" : "+person.getAge());
        }
        System.out.println(Thread.currentThread().getName()+" ended.");
    }
    
}
