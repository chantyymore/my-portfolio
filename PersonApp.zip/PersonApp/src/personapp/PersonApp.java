
package personapp;

import za.ac.tut.bl.PersonThread;
import za.ac.tut.entity.Person;

public class PersonApp {

    public static void main(String[] args) {
        Person person = new Person();
        PersonThread pt = new PersonThread(person);
        
        Thread t1 = new Thread(pt);
        Thread t2 = new Thread(pt);
        
        //give two threads proper names
        t1.setName("Tumi");
        t2.setName("Thato");
        
        t1.start();
        t2.start();
    }
    
}
