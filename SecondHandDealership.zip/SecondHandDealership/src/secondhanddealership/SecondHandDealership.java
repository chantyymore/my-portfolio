package secondhanddealership;

import java.util.ArrayList;
import java.util.Scanner;
import za.ac.tut.vehicle.Vehicle;

public class SecondHandDealership {
    public final int CURRENT_YEAR = 2023;
    public static void main(String[] args) {
        String[] vehicleInfo = {"FG34QWGP#2015#17367.6#true",
				"SP45DHGP#2013#83431.8#true",
				"SDT291NC#2008#134984.3#false",
				"SPR917FS#2011#99346.3#false",
				"JW18XPGP#2012#104368.1#true",
				"CCP667NW#2013#78364.9#true",
				"AR22DDGP#2014#66714.5#true",
				"POD524NC#2013#49366.6#false",
				"LJ76EGGP#2013#104258.8#true"};
        ArrayList<Vehicle> vehicles = new ArrayList<>();
        System.out.println("The list of Vehicle Registration numbers");
        System.out.println("==========================================");
        for(int i=0;i<vehicleInfo.length;i++){
            String[] token = vehicleInfo[i].split("#");
            
            String regNumber = token[0];
            int yearModel = Integer.parseInt(token[1]);
            double kilometers = Double.parseDouble(token[2]);
            boolean serviceHistory = Boolean.parseBoolean(token[3]);
            
            Vehicle vehicle = new Vehicle(regNumber, yearModel, kilometers, serviceHistory);
            vehicles.add(vehicle);
            System.out.println(registrationNumbers(vehicles));
        }
        Scanner pad = new Scanner(System.in);
        System.out.print("Enter the vehicle Registration Number of the requested vehicle: ");
        String registrationNo = pad.next();
        double averageKilo = averageKilometers(vehicles,registrationNo);
        System.out.print("The average kilometers traveled by the vehicle per year is "+averageKilo+"km");
    }
    public static String registrationNumbers(ArrayList<Vehicle> vehicles){
       String registration =null;
       for(int i=0;i<vehicles.size();i++){
          registration = vehicles.get(i).getRegNumber();
       }
       return registration;
    }
    public static double averageKilometers(ArrayList<Vehicle> vehicles,String registrationNo){
     
        double average =0.0;
        double sum=0.0;
        int count =0;
        for(int i=0;i<vehicles.size();i++){
          if(vehicles.get(i).getRegNumber().equalsIgnoreCase(registrationNo)){
              sum += vehicles.get(i).getKilometers();
              count += vehicles.get(i).getRegNumber().length();
          }
       }
       average = ((sum/count)*12);
       return average;
    }
}
