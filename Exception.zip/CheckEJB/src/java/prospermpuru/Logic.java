package prospermpuru;

import javax.ejb.Stateless;

//@author prospermpuru
@Stateless
public class Logic implements LogicLocal {

    @Override
    public void Check(String number) throws ErrorEx {

        if (number.length() == 5) {
        } else {
            throw new ErrorEx(number + " is not 5 digits");
        }
    }
}
