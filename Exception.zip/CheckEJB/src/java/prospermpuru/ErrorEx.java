/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prospermpuru;

import javax.ejb.EJBException;

/**
 *
 * @author prospermpuru
 */
public class ErrorEx extends EJBException{

    public ErrorEx(String message) {
        super(message);
    }
    
}
