/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package prospermpuru;

import javax.ejb.Local;

/**
 *
 * @author prospermpuru
 */
@Local
public interface LogicLocal {

    void Check(String number);
    
}
