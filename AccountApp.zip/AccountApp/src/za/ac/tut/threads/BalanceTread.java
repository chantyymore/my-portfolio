
package za.ac.tut.threads;

import za.ac.tut.bl.AccountManager;

public class BalanceTread extends Thread{
    private AccountManager am;

    public BalanceTread(AccountManager am) {
        this.am = am;
    }

    @Override
    public synchronized void run() {
        am.balance();
    }
    
}
