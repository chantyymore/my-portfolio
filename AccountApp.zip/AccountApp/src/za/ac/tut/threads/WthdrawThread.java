
package za.ac.tut.threads;

import za.ac.tut.bl.AccountManager;

public class WthdrawThread extends Thread{
    private double amount;
    private AccountManager am;

    public WthdrawThread(double amount, AccountManager am) {
        this.amount = amount;
        this.am = am;
    }

    @Override
    public synchronized void run() {
        am.withdraw(amount);
    }
    
}
