
package za.ac.tut.entity;
        
public class Account {
    private double amount;

    public Account() {
        amount = 100.00;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
    
}
