
package za.ac.tut.bl;

import za.ac.tut.entity.Account;

public interface AccountManagerInterface {
    public void balance();
    public void withdraw(double amount);
    public void deposit(double amount);
}
