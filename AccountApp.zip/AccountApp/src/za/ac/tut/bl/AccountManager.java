
package za.ac.tut.bl;

import za.ac.tut.entity.Account;

public class AccountManager implements AccountManagerInterface{
    private Account account;

    public AccountManager(Account account) {
        this.account = account;
    }
    
    @Override
    public void balance() {
         double balance= account.getAmount();
         System.out.println(Thread.currentThread().getName()+" checking balance--> R:"+balance);
    }

    @Override
    public void withdraw(double amount) {
        double balance,initialBalance;
        for(int i=0;i<1;i++){
            balance = account.getAmount();
            initialBalance = balance;
            if(amount < balance){
 
                balance -= amount;
                account.setAmount(balance);
                System.out.println(Thread.currentThread().getName()+"-->Initial balance :R"+initialBalance+"-->Withdrawn amount: R"+amount+"-->Current amount: R"+account.getAmount());
        
            }
        }
    }

    @Override
    public void deposit(double amount) {
        double balance,initialBalance;
        balance = account.getAmount();
        initialBalance = balance;
        
        balance += amount;
        account.setAmount(balance);
        System.out.println(Thread.currentThread().getName()+"-->Initial balance: R"+initialBalance+"-->deposited amount: R"+amount+"-->Current amount: R"+account.getAmount());
    }
    
}
