
package accountapp;

import za.ac.tut.bl.AccountManager;
import za.ac.tut.entity.Account;
import za.ac.tut.threads.BalanceTread;
import za.ac.tut.threads.DepositThread;
import za.ac.tut.threads.WthdrawThread;

public class AccountApp {

    public static void main(String[] args) {
        Account account = new Account();
        AccountManager am = new AccountManager(account);
        
        DepositThread t1 = new DepositThread(1000, am);
        WthdrawThread t2 = new WthdrawThread(200, am);
        WthdrawThread t3 = new WthdrawThread(500, am);
        WthdrawThread t4 = new WthdrawThread(100, am);
        BalanceTread t5 = new BalanceTread(am);
        DepositThread t6 = new DepositThread(400, am);
        
        t1.setName("Daughter");
        t2.setName("Mom");
        t3.setName("Dad");
        t4.setName("Grandson");
        t5.setName("Son");
        t6.setName("Granddaughter");
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        
    }
    
}
