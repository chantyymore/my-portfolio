
package za.ac.tut.entity;

public class Numbers {
    
    public Numbers() {
    }

    public String generateOddNumbers(){
        String numbers="";
        
        for(int i=0;i<10;i++){
            if((i%2)!=0){
                numbers = numbers +i+" ";
            }
        }
        return numbers;
    }
    
    public String generateEvenNumbers(){
        String numbers="";
        
        for(int i=0;i<10;i++){
            if((i%2)==0){
                numbers = numbers +i+" ";
            }
        }
        return numbers;
    }
}
