
package za.ac.tut.bl;

import za.ac.tut.entity.Numbers;

public class EvenNumbersGeneratorThread extends Thread{

    public EvenNumbersGeneratorThread() {
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread()+" has started");
        Numbers numbers = new Numbers();
        String generatedNumbers =numbers.generateEvenNumbers();
        System.out.println(generatedNumbers);
        System.out.println(Thread.currentThread()+" has ended0");        
    }
 
}
