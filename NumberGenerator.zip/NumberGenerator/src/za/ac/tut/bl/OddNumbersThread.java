
package za.ac.tut.bl;

import za.ac.tut.entity.Numbers;

public class OddNumbersThread extends Thread{

    public OddNumbersThread() {
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread()+" has started.");
        Numbers numbers = new Numbers();
        String generatedNumbers = numbers.generateOddNumbers();
        System.out.println(generatedNumbers);
        System.out.println(Thread.currentThread()+" has ended.");
    }
    
}
