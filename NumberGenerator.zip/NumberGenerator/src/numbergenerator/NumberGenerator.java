
package numbergenerator;

import za.ac.tut.bl.EvenNumbersGeneratorThread;
import za.ac.tut.bl.OddNumbersThread;

public class NumberGenerator {

    public static void main(String[] args) {
        OddNumbersThread ogt;
        EvenNumbersGeneratorThread egt;
        
        ogt = new OddNumbersThread();
        ogt.setName("Odd Numbers Thread");
        egt = new EvenNumbersGeneratorThread();
        egt.setName("Even Numbers Thread");
        
        ogt.start();
        egt.start();
    }
    
}
